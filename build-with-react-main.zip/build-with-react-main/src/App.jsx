import ListCard from "./components/ListCard";
import Penjumlahan from "./components/Penjumlahan";
import "./styles/App.css";

function App() {
  return (
    <>
      <Penjumlahan />
      <ListCard />
    </>
  );
}

export default App;
